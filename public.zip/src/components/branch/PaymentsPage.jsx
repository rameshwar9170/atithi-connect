import React from 'react';

function PaymentsPage() {
  return (
    <div>
      <h2>Payments</h2>
      <p>Review transactions and manage payment records.</p>
    </div>
  );
}

export default PaymentsPage;