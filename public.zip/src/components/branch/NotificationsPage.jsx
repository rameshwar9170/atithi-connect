import React from 'react';

function NotificationsPage() {
  return (
    <div>
      <h2>Notifications</h2>
      <p>View and manage system and staff notifications.</p>
    </div>
  );
}

export default NotificationsPage;