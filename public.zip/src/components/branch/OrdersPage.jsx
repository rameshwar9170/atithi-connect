import React, { useState, useEffect } from 'react';
import { ref, onValue, set, push, update } from 'firebase/database';
import { db } from '../../firebase/config';
import './OrdersPage.css';

function OrdersPage() {
  const branchId = localStorage.getItem('branchId');
  const [tables, setTables] = useState([]);
  const [menuItems, setMenuItems] = useState([]);
  const [selectedTable, setSelectedTable] = useState(null);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [tableOrders, setTableOrders] = useState({});
  const [total, setTotal] = useState(0);
  const [showBillForm, setShowBillForm] = useState(false);
  const [customer, setCustomer] = useState({ name: '', phone: '' });

  useEffect(() => {
    if (!branchId) return;

    const branchRef = ref(db, `atithi-connect/Branches/${branchId}`);
    const unsubscribe = onValue(branchRef, snapshot => {
      const data = snapshot.val();
      if (!data) return;

      let tablesData = [];
      if (data.tables) {
        if (Array.isArray(data.tables)) {
          // Handle array format - preserve original indices, including null entries
          tablesData = data.tables.map((table, index) => {
            if (table && table.tableId) {
              return {
                ...table,
                firebaseIndex: index,
                status: table.status || 'available'
              };
            }
            return null;
          }).filter(Boolean);
        } else {
          // Handle object format
          tablesData = Object.entries(data.tables).map(([key, table]) => ({
            ...table,
            firebaseKey: key,
            status: table.status || 'available'
          }));
        }
      }
      
      setTables(tablesData);
      
      const allMenu = data.Menu ? Object.values(data.Menu).filter(item => item.isAvailable) : [];
      setMenuItems(allMenu);

      // Only initialize orders for new tables
      setTableOrders(prev => {
        const newOrders = { ...prev };
        tablesData.forEach(table => {
          const tableId = table.tableId;
          if (!newOrders[tableId]) {
            newOrders[tableId] = [];
          }
        });
        return newOrders;
      });
    });

    return () => unsubscribe();
  }, [branchId]);

  useEffect(() => {
    setResults(
      query
        ? menuItems.filter(item =>
            item.itemName.toLowerCase().includes(query.toLowerCase())
          )
        : []
    );
  }, [query, menuItems]);

  useEffect(() => {
    if (selectedTable && tableOrders[selectedTable.tableId]) {
      const tableTotal = tableOrders[selectedTable.tableId].reduce((sum, item) => sum + item.subtotal, 0);
      setTotal(tableTotal);
    } else {
      setTotal(0);
    }
  }, [selectedTable, tableOrders]);

  const handleTableSelect = (table) => {
    setSelectedTable(table);
    setQuery('');
    setResults([]);
  };

  const handleAdd = async (item) => {
    if (!selectedTable) {
      alert('Please select a table first');
      return;
    }

    const tableId = selectedTable.tableId;
    const currentOrders = tableOrders[tableId] || [];
    
    setTableOrders(prev => {
      const updatedOrders = { ...prev };
      const existingItem = currentOrders.find(i => i.menuId === item.menuId);
      
      if (existingItem) {
        updatedOrders[tableId] = currentOrders.map(i =>
          i.menuId === item.menuId
            ? { ...i, quantity: i.quantity + 1, subtotal: (i.quantity + 1) * i.itemPrice }
            : i
        );
      } else {
        updatedOrders[tableId] = [...currentOrders, { 
          ...item, 
          quantity: 1, 
          subtotal: item.itemPrice 
        }];
      }
      
      return updatedOrders;
    });

    // Update table status only if it's currently available
    if (selectedTable.status === 'available') {
      await updateTableStatus(selectedTable, 'booked');
    }

    setQuery('');
    setResults([]);
  };

  const updateTableStatus = async (table, status) => {
    try {
      if (!table || !table.tableId) {
        console.error('Invalid table provided:', table);
        return;
      }

      let updatePath = '';
      
      // Determine the correct Firebase path based on table structure
      if (table.firebaseIndex !== undefined) {
        // Array-based structure - make sure we're updating the exact index
        updatePath = `atithi-connect/Branches/${branchId}/tables/${table.firebaseIndex}/status`;
      } else if (table.firebaseKey) {
        // Object-based structure
        updatePath = `atithi-connect/Branches/${branchId}/tables/${table.firebaseKey}/status`;
      } else {
        console.error('No Firebase reference found for table:', table);
        return;
      }

      console.log('Updating table status:', {
        tableId: table.tableId,
        tableNumber: table.tableNumber,
        firebaseIndex: table.firebaseIndex,
        path: updatePath,
        status: status
      });

      // Create the update object
      const updates = {};
      updates[updatePath] = status;

      // Perform the update
      await update(ref(db), updates);

      // Update local state immediately
      setTables(prev => prev.map(t => 
        t.tableId === table.tableId ? { ...t, status } : t
      ));
      
      // Update selected table if it matches
      if (selectedTable?.tableId === table.tableId) {
        setSelectedTable(prev => ({ ...prev, status }));
      }

      console.log(`Successfully updated table ${table.tableId} status to ${status}`);
    } catch (error) {
      console.error('Error updating table status:', error);
      alert('Error updating table status. Please try again.');
    }
  };

  const removeItem = async (menuId) => {
    if (!selectedTable) return;

    const tableId = selectedTable.tableId;
    const currentOrders = tableOrders[tableId] || [];
    const remainingItems = currentOrders.filter(item => item.menuId !== menuId);
    
    setTableOrders(prev => {
      const updatedOrders = { ...prev };
      updatedOrders[tableId] = remainingItems;
      return updatedOrders;
    });

    // If no more items and table is booked, make it available
    if (remainingItems.length === 0 && selectedTable.status === 'booked') {
      await updateTableStatus(selectedTable, 'available');
    }
  };

  const updateQuantity = (menuId, newQuantity) => {
    if (newQuantity < 1 || !selectedTable) return;

    const tableId = selectedTable.tableId;
    
    setTableOrders(prev => {
      const updatedOrders = { ...prev };
      updatedOrders[tableId] = prev[tableId].map(item =>
        item.menuId === menuId
          ? { ...item, quantity: newQuantity, subtotal: newQuantity * item.itemPrice }
          : item
      );
      return updatedOrders;
    });
  };

  const handleGenerate = () => {
    if (!selectedTable || !tableOrders[selectedTable.tableId]?.length) {
      alert('No items to generate bill for');
      return;
    }
    setShowBillForm(true);
  };

 const handleBillSubmit = async (e) => {
  e.preventDefault();
  
  if (!customer.name.trim() || !customer.phone.trim()) {
    alert('Please fill in all customer details');
    return;
  }
  
  try {
    const billRef = ref(db, `atithi-connect/Branches/${branchId}/Bills`);
    const newBill = push(billRef);
    
    await set(newBill, {
      billId: newBill.key,
      table: selectedTable.tableNumber,
      customer,
      items: tableOrders[selectedTable.tableId],
      total,
      createdAt: Date.now(),
    });

    // Clear table orders
    setTableOrders(prev => ({
      ...prev,
      [selectedTable.tableId]: []
    }));
    
    // Update table status to available
    await updateTableStatus(selectedTable, 'available');
    
    // Reset form
    setCustomer({ name: '', phone: '' });
    setShowBillForm(false);
    
    // Removed the success alert
    // alert('Bill generated and saved successfully!');
  } catch (error) {
    console.error('Error saving bill:', error);
    alert('Error saving bill. Please try again.');
  }
};

  const getCurrentOrders = () => {
    return selectedTable ? (tableOrders[selectedTable.tableId] || []) : [];
  };

  const clearTableOrders = async () => {
    if (!selectedTable || !window.confirm('Are you sure you want to clear all orders for this table?')) {
      return;
    }

    setTableOrders(prev => ({
      ...prev,
      [selectedTable.tableId]: []
    }));

    // Update table status to available if it was booked
    if (selectedTable.status === 'booked') {
      await updateTableStatus(selectedTable, 'available');
    }
  };

  return (
    <div className="orders-page-container">
      {/* Tables Section */}
      <div className="restaurant-tables-section">
        <h2 className="restaurant-tables-title">Restaurant Tables</h2>
        <div className="restaurant-tables-grid">
          {tables.map(table => (
            <div
              key={table.tableId}
              className={`restaurant-table-card ${table.status === 'available' ? 'table-available' : 'table-booked'} ${selectedTable?.tableId === table.tableId ? 'table-selected' : ''}`}
              onClick={() => handleTableSelect(table)}
            >
              <div className="restaurant-table-number">Table {table.tableNumber}</div>
              <div className="restaurant-table-status">
                {table.status === 'available' ? 'Available' : 'Booked'}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Main Content Area */}
      <div className="orders-main-content">
        {/* Selected Table Header & Search */}
        <div className="selected-table-section">
          <h3 className="selected-table-title">
            {selectedTable ? `Table ${selectedTable.tableNumber}` : 'Select a Table'}
          </h3>
          {selectedTable && (
            <div className="menu-search-container">
              <input
                type="text"
                placeholder="Search menu items..."
                value={query}
                onChange={e => setQuery(e.target.value)}
                className="menu-search-input"
              />
            </div>
          )}
        </div>
        
        {/* Search Results */}
        {results.length > 0 && (
          <div className="menu-search-results">
            {results.map(item => (
              <div 
                key={item.menuId} 
                className="menu-search-item" 
                onClick={() => handleAdd(item)}
              >
                <span className="menu-search-item-name">{item.itemName}</span>
                <span className="menu-search-item-price">₹{item.itemPrice}</span>
              </div>
            ))}
          </div>
        )}

        {/* Order Items Table */}
        <div className="order-items-section">
          {selectedTable ? (
            getCurrentOrders().length > 0 ? (
              <div className="order-items-table">
                <div className="order-table-header">
                  <div className="order-header-item">Item</div>
                  <div className="order-header-price">Price</div>
                  <div className="order-header-quantity">Quantity</div>
                  <div className="order-header-total">Total</div>
                  <div className="order-header-action">Action</div>
                </div>
                {getCurrentOrders().map(item => (
                  <div key={item.menuId} className="order-table-row">
                    <div className="order-row-item">{item.itemName}</div>
                    <div className="order-row-price">₹{item.itemPrice}</div>
                    <div className="order-row-quantity">
                      <div className="quantity-controls">
                        <button 
                          className="quantity-btn quantity-decrease"
                          onClick={() => updateQuantity(item.menuId, item.quantity - 1)}
                        >
                          −
                        </button>
                        <span className="quantity-value">{item.quantity}</span>
                        <button 
                          className="quantity-btn quantity-increase"
                          onClick={() => updateQuantity(item.menuId, item.quantity + 1)}
                        >
                          +
                        </button>
                      </div>
                    </div>
                    <div className="order-row-total">₹{item.subtotal}</div>
                    <div className="order-row-action">
                      <button 
                        onClick={() => removeItem(item.menuId)} 
                        className="remove-item-btn"
                      >
                        ×
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="empty-order-state">
                <div className="empty-order-icon">🍽️</div>
                <p className="empty-order-message">No items added yet. Search and add items from the menu.</p>
              </div>
            )
          ) : (
            <div className="no-table-selected-state">
              <div className="no-table-icon">🏪</div>
              <h3 className="no-table-title">Select a Table</h3>
              <p className="no-table-message">Choose a table from above to start taking orders</p>
            </div>
          )}
        </div>

        {/* Clear All Orders Button */}
        {selectedTable && getCurrentOrders().length > 0 && (
          <div className="clear-orders-section">
            <button 
              onClick={clearTableOrders}
              className="clear-all-orders-btn"
            >
              Clear All Orders
            </button>
          </div>
        )}
      </div>

      {/* Footer with Total and Generate Bill */}
      <div className="orders-page-footer">
        <div className="total-amount-display">
          <span className="total-label-text">Total: </span>
          <span className="total-amount-value">₹{total}</span>
        </div>
        <button
          className={`generate-bill-btn ${getCurrentOrders().length === 0 ? 'generate-bill-disabled' : ''}`}
          onClick={handleGenerate}
          disabled={getCurrentOrders().length === 0}
        >
          Generate Bill
        </button>
      </div>

      {/* Bill Modal */}
      {showBillForm && (
        <div className="bill-generation-modal">
          <div className="bill-modal-content">
            <h3 className="bill-modal-title">Customer Details</h3>
            <form onSubmit={handleBillSubmit} className="bill-customer-form">
              <div className="bill-form-group">
                <label className="bill-form-label">Customer Name *</label>
                <input
                  type="text"
                  value={customer.name}
                  onChange={e => setCustomer({...customer, name: e.target.value})}
                  placeholder="Enter customer name"
                  className="bill-form-input"
                  required
                />
              </div>
              <div className="bill-form-group">
                <label className="bill-form-label">Phone Number *</label>
                <input
                  type="tel"
                  value={customer.phone}
                  onChange={e => setCustomer({...customer, phone: e.target.value})}
                  placeholder="Enter phone number"
                  className="bill-form-input"
                  required
                />
              </div>
              <div className="bill-form-actions">
                <button 
                  type="button" 
                  className="bill-cancel-btn"
                  onClick={() => setShowBillForm(false)}
                >
                  Cancel
                </button>
                <button type="submit" className="bill-submit-btn">
                  Save Bill
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>  
  );
}

export default OrdersPage;