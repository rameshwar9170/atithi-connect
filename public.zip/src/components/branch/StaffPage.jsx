import React from 'react';

function StaffPage() {
  return (
    <div>
      <h2>Staff Management</h2>
      <p>View, add, or remove staff members for this branch.</p>
    </div>
  );
}

export default StaffPage;