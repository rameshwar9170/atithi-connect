import React from 'react';

function BillingPage() {
  return (
    <div>
      <h2>Billing</h2>
      <p>Create and manage customer bills and invoices.</p>
    </div>
  );
}

export default BillingPage;