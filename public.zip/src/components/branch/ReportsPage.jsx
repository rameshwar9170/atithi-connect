import React from 'react';

function ReportsPage() {
  return (
    <div>
      <h2>Reports</h2>
      <p>Generate and view sales and performance reports.</p>
    </div>
  );
}

export default ReportsPage;